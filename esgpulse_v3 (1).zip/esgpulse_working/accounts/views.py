from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.conf import settings
from .forms import RegisterForm, LoginForm
import json
import logging

logger = logging.getLogger(__name__)


def index(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'index.html')


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = RegisterForm()
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            messages.success(request, f'Welcome to ESGPulse, {user.full_name}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = LoginForm()
    if request.method == 'POST':
        email    = request.POST.get('username')
        password = request.POST.get('password')
        user     = authenticate(request, email=email, password=password)
        if user:
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            messages.success(request, f'Welcome back, {user.full_name}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid email or password.')
    return render(request, 'accounts/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('login')


# ─────────────────────────────────────────────
#  GOOGLE SSO — OAuth2 callback
# ─────────────────────────────────────────────
def sso_google_callback(request):
    """
    Google redirects here after user approves.
    We exchange the 'code' for tokens, fetch user info, then log in.
    """
    from .models import User

    # ── 1. Check for errors from Google ──
    error = request.GET.get('error')
    code  = request.GET.get('code')

    if error:
        messages.error(request, f'Google Sign-In declined: {error}')
        return redirect('login')
    if not code:
        messages.error(request, 'Google did not return an authorization code. Please try again.')
        return redirect('login')

    client_id     = getattr(settings, 'GOOGLE_CLIENT_ID', '')
    client_secret = getattr(settings, 'GOOGLE_CLIENT_SECRET', '')
    redirect_uri  = getattr(settings, 'GOOGLE_REDIRECT_URI', 'http://127.0.0.1:8000/sso/google/callback/')

    if not client_id or not client_secret:
        messages.error(request, 'Google SSO credentials are not configured in settings.py.')
        return redirect('login')

    # ── 2. Exchange code for access token ──
    try:
        import urllib.request
        import urllib.parse
        import urllib.error

        token_payload = urllib.parse.urlencode({
            'code':          code,
            'client_id':     client_id,
            'client_secret': client_secret,
            'redirect_uri':  redirect_uri,
            'grant_type':    'authorization_code',
        }).encode('utf-8')

        token_request = urllib.request.Request(
            'https://oauth2.googleapis.com/token',
            data=token_payload,
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            method='POST'
        )

        import ssl
        ctx = ssl.create_default_context()
        with urllib.request.urlopen(token_request, timeout=15, context=ctx) as resp:
            token_data = json.loads(resp.read().decode('utf-8'))

    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        logger.error(f'Google token exchange HTTPError {e.code}: {body}')
        messages.error(request, f'Google authentication failed (token error {e.code}). Check your credentials and redirect URI.')
        return redirect('login')
    except Exception as e:
        logger.error(f'Google token exchange error: {e}')
        messages.error(request, f'Google authentication error: {e}')
        return redirect('login')

    access_token = token_data.get('access_token')
    if not access_token:
        err_desc = token_data.get('error_description', token_data.get('error', 'No access token returned'))
        logger.error(f'No access_token in Google response: {token_data}')
        messages.error(request, f'Google returned no access token: {err_desc}')
        return redirect('login')

    # ── 3. Fetch user profile ──
    try:
        import ssl
        ctx = ssl.create_default_context()
        profile_request = urllib.request.Request(
            'https://www.googleapis.com/oauth2/v2/userinfo',
            headers={'Authorization': f'Bearer {access_token}'}
        )
        with urllib.request.urlopen(profile_request, timeout=15, context=ctx) as resp:
            profile = json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        logger.error(f'Google profile fetch error: {e}')
        messages.error(request, f'Could not fetch your Google profile: {e}')
        return redirect('login')

    email     = profile.get('email', '').strip().lower()
    full_name = profile.get('name', '').strip() or email.split('@')[0].replace('.', ' ').title()
    picture   = profile.get('picture', '')

    if not email:
        messages.error(request, 'Your Google account did not provide an email address.')
        return redirect('login')

    if not profile.get('verified_email', True):
        messages.error(request, 'Your Google email address is not verified. Please verify it first.')
        return redirect('login')

    # ── 4. Get or create user ──
    user, created = User.objects.get_or_create(
        email=email,
        defaults={
            'full_name': full_name,
            'role':      'user',
            'is_active': True,
        }
    )

    if created:
        user.set_unusable_password()
        user.save()
        logger.info(f'New user created via Google SSO: {email}')
        messages.success(request, f'Welcome to ESGPulse, {full_name}! Your account was created with Google.')
    else:
        # Update name if changed in Google
        if user.full_name != full_name and full_name:
            user.full_name = full_name
            user.save(update_fields=['full_name'])
        messages.success(request, f'Welcome back, {user.full_name}!')

    if not user.is_active:
        messages.error(request, 'Your account has been deactivated. Contact your administrator.')
        return redirect('login')

    login(request, user, backend='django.contrib.auth.backends.ModelBackend')
    logger.info(f'User logged in via Google SSO: {email}')

    # Store SSO provider in session for reference
    request.session['sso_provider'] = 'google'
    request.session['sso_picture']  = picture

    return redirect('dashboard')


# ─────────────────────────────────────────────
#  MICROSOFT SSO — OAuth2 callback
# ─────────────────────────────────────────────
def sso_microsoft_callback(request):
    from .models import User

    error = request.GET.get('error')
    code  = request.GET.get('code')

    if error:
        messages.error(request, f'Microsoft Sign-In declined: {error}')
        return redirect('login')
    if not code:
        messages.error(request, 'Microsoft did not return an authorization code.')
        return redirect('login')

    client_id     = getattr(settings, 'MICROSOFT_CLIENT_ID', '')
    client_secret = getattr(settings, 'MICROSOFT_CLIENT_SECRET', '')
    tenant_id     = getattr(settings, 'MICROSOFT_TENANT_ID', 'common')
    redirect_uri  = getattr(settings, 'MICROSOFT_REDIRECT_URI', 'http://127.0.0.1:8000/sso/microsoft/callback/')

    if not client_id or not client_secret:
        messages.error(request, 'Microsoft SSO credentials are not configured.')
        return redirect('login')

    try:
        import urllib.request, urllib.parse, urllib.error, ssl
        ctx = ssl.create_default_context()

        token_payload = urllib.parse.urlencode({
            'client_id':     client_id,
            'client_secret': client_secret,
            'code':          code,
            'redirect_uri':  redirect_uri,
            'grant_type':    'authorization_code',
            'scope':         'openid email profile User.Read',
        }).encode('utf-8')

        token_url     = f'https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token'
        token_request = urllib.request.Request(
            token_url, data=token_payload,
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            method='POST'
        )
        with urllib.request.urlopen(token_request, timeout=15, context=ctx) as resp:
            token_data   = json.loads(resp.read().decode('utf-8'))
        access_token = token_data.get('access_token')
        if not access_token:
            raise ValueError(token_data.get('error_description', 'No access token'))

        profile_request = urllib.request.Request(
            'https://graph.microsoft.com/v1.0/me',
            headers={'Authorization': f'Bearer {access_token}'}
        )
        with urllib.request.urlopen(profile_request, timeout=15, context=ctx) as resp:
            profile = json.loads(resp.read().decode('utf-8'))

    except Exception as e:
        logger.error(f'Microsoft SSO error: {e}')
        messages.error(request, f'Microsoft authentication failed: {e}')
        return redirect('login')

    email     = (profile.get('mail') or profile.get('userPrincipalName', '')).lower().strip()
    full_name = profile.get('displayName', '').strip() or email.split('@')[0].title()

    if not email:
        messages.error(request, 'Microsoft did not provide an email address.')
        return redirect('login')

    user, created = User.objects.get_or_create(
        email=email,
        defaults={'full_name': full_name, 'role': 'user', 'is_active': True}
    )
    if created:
        user.set_unusable_password()
        user.save()
        messages.success(request, f'Welcome to ESGPulse, {full_name}! Account created via Microsoft.')
    else:
        messages.success(request, f'Welcome back, {user.full_name}!')

    if not user.is_active:
        messages.error(request, 'Your account is deactivated.')
        return redirect('login')

    login(request, user, backend='django.contrib.auth.backends.ModelBackend')
    request.session['sso_provider'] = 'microsoft'
    return redirect('dashboard')


# ─────────────────────────────────────────────
#  COOKIE CONSENT API
# ─────────────────────────────────────────────
@require_POST
def cookie_consent(request):
    try:
        data   = json.loads(request.body)
        choice = data.get('choice', 'reject')
    except Exception:
        choice = 'reject'

    response = JsonResponse({'ok': True, 'choice': choice})
    response.set_cookie('cookie_consent', choice, max_age=365*24*60*60, samesite='Lax')
    request.session['cookie_consent'] = choice
    return response
