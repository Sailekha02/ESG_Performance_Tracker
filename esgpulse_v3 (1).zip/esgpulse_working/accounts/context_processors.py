from django.conf import settings


def sso_settings(request):
    """Expose SSO client IDs to all templates (never expose secrets)."""
    return {
        'GOOGLE_CLIENT_ID':     getattr(settings, 'GOOGLE_CLIENT_ID', ''),
        'MICROSOFT_CLIENT_ID':  getattr(settings, 'MICROSOFT_CLIENT_ID', ''),
        'MICROSOFT_TENANT_ID':  getattr(settings, 'MICROSOFT_TENANT_ID', 'common'),
    }
