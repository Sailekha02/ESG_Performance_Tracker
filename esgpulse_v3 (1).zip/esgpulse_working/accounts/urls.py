from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # SSO callbacks
    path('sso/google/callback/', views.sso_google_callback, name='sso_google_callback'),
    path('sso/microsoft/callback/', views.sso_microsoft_callback, name='sso_microsoft_callback'),

    # Cookie consent API
    path('api/cookie-consent/', views.cookie_consent, name='cookie_consent'),
]
