from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .models import User


class RegisterForm(forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Min 8 characters'}),
        min_length=8
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Re-enter your password'})
    )

    class Meta:
        model = User
        fields = ['full_name', 'phone', 'email', 'company', 'role', 'password']
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Arjun Sharma'}),
            'phone': forms.TextInput(attrs={'placeholder': '+91 9876543210'}),
            'email': forms.EmailInput(attrs={'placeholder': 'arjun@company.com'}),
            'company': forms.TextInput(attrs={'placeholder': 'Green Corp Pvt. Ltd.'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        pw = cleaned_data.get('password')
        cpw = cleaned_data.get('confirm_password')
        if pw and cpw and pw != cpw:
            raise forms.ValidationError('Passwords do not match.')
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        if commit:
            user.save()
        return user


class LoginForm(AuthenticationForm):
    username = forms.EmailField(
        label='Email Address',
        widget=forms.EmailInput(attrs={'placeholder': 'you@company.com'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': '••••••••'})
    )
    role = forms.ChoiceField(
        choices=[('', 'Select your role'), ('manager', 'ESG Manager'), ('user', 'Company User')],
        required=False
    )
