"""
ESGPulse Django Settings
MySQL + Full Authentication + ESG Data Management
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-esgpulse-change-this-in-production-xyz789'

DEBUG = True

ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'accounts',
    'esg',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'esgpulse.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'accounts.context_processors.sso_settings',
            ],
        },
    },
]

WSGI_APPLICATION = 'esgpulse.wsgi.application'

# ─────────────────────────────────────────────
#  DATABASE — MySQL
#  pip install mysqlclient
#  Create DB: CREATE DATABASE esgpulse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
# ─────────────────────────────────────────────
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'esgpulse',
        'USER': 'root',         # ← change to your MySQL username
        'PASSWORD': 'Ramya@123', # ← change to your MySQL password
        'HOST': '127.0.0.1',
        'PORT': '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        },
    }
}

# Custom User Model
AUTH_USER_MODEL = 'accounts.User'

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'esgpulse' / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/dashboard/'
LOGOUT_REDIRECT_URL = '/'

# Session
SESSION_COOKIE_AGE = 86400  # 1 day
SESSION_SAVE_EVERY_REQUEST = True

# ─────────────────────────────────────────────
#  SSO — Google OAuth2
#  Steps:
#  1. Go to https://console.cloud.google.com/
#  2. Create project → Enable "Google+ API" / "Google Identity"
#  3. Credentials → Create OAuth 2.0 Client ID (Web Application)
#  4. Add Authorized redirect URI: http://127.0.0.1:8000/sso/google/callback/
#  5. Copy Client ID and Client Secret below
# ─────────────────────────────────────────────
GOOGLE_CLIENT_ID     = '392076918765-8k28414sotvp6tte43pd61rcl39qgprh.apps.googleusercontent.com'
GOOGLE_CLIENT_SECRET = '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'
GOOGLE_REDIRECT_URI  = 'http://127.0.0.1:8000/sso/google/callback/'

# ─────────────────────────────────────────────
#  SSO — Microsoft (Azure AD) OAuth2
#  Steps:
#  1. Go to https://portal.azure.com/ → Azure Active Directory
#  2. App registrations → New registration
#  3. Redirect URI (Web): http://127.0.0.1:8000/sso/microsoft/callback/
#  4. Certificates & Secrets → New client secret
#  5. Copy Application (client) ID and Secret below
# ─────────────────────────────────────────────
MICROSOFT_CLIENT_ID     = ''   # ← paste your Azure Application (client) ID
MICROSOFT_CLIENT_SECRET = ''   # ← paste your Azure Client Secret value
MICROSOFT_TENANT_ID     = 'common'   # or your specific tenant ID
MICROSOFT_REDIRECT_URI  = 'http://127.0.0.1:8000/sso/microsoft/callback/'

# ─────────────────────────────────────────────
#  AUTHENTICATION BACKENDS
# ─────────────────────────────────────────────
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
]

# ─────────────────────────────────────────────
#  LOGGING — see SSO errors in the console
# ─────────────────────────────────────────────
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
    },
    'formatters': {
        'simple': {
            'format': '[%(levelname)s %(name)s] %(message)s'
        },
    },
    'loggers': {
        'accounts': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': True,
        },
    },
}
