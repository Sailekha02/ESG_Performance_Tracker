# ESGPulse — Django + MySQL Full Stack Setup Guide

## Project Structure

```
esgpulse/
├── manage.py
├── requirements.txt
├── esgpulse/                  ← Django project config
│   ├── settings.py            ← DB, auth, installed apps
│   ├── urls.py                ← Root URL router
│   └── wsgi.py
├── accounts/                  ← Auth app (custom User model)
│   ├── models.py              ← User (email, role, company)
│   ├── views.py               ← login, register, logout
│   ├── forms.py
│   ├── urls.py
│   └── admin.py
├── esg/                       ← Core ESG app
│   ├── models.py              ← ESGRecord, EnvironmentalData, SocialData, GovernanceData
│   ├── views.py               ← dashboard, data entry wizard, reports, chatbot API
│   ├── forms.py
│   ├── urls.py
│   └── admin.py
├── templates/
│   ├── base.html
│   ├── index.html             ← Landing page
│   ├── partials/
│   │   └── sidebar.html
│   ├── accounts/
│   │   ├── login.html
│   │   └── register.html
│   └── esg/
│       ├── dashboard.html
│       ├── data_entry_start.html
│       ├── data_entry_env.html
│       ├── data_entry_social.html
│       ├── data_entry_gov.html
│       ├── data_entry_review.html
│       └── reports.html
└── static/
```

---

## Database Schema (MySQL)

| Table                | Description                          |
|----------------------|--------------------------------------|
| `esg_users`          | Custom user model (email, role, co.) |
| `esg_records`        | Master ESG record + calculated scores|
| `esg_environmental`  | Energy, emissions, water, waste data |
| `esg_social`         | Workforce, safety, CSR data          |
| `esg_governance`     | Board, policies, audit data          |

---

## Quick Start (Step by Step)

### 1. Prerequisites
- Python 3.10+
- MySQL 8.0+
- pip

### 2. Create MySQL Database
```sql
CREATE DATABASE esgpulse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'esguser'@'localhost' IDENTIFIED BY 'yourpassword';
GRANT ALL PRIVILEGES ON esgpulse.* TO 'esguser'@'localhost';
FLUSH PRIVILEGES;
```

### 3. Configure Database in settings.py
Edit `esgpulse/settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'esgpulse',
        'USER': 'esguser',        # ← your MySQL user
        'PASSWORD': 'yourpassword', # ← your MySQL password
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

### 4. Install Python Dependencies
```bash
pip install -r requirements.txt
```

> **Note:** If `mysqlclient` fails, install build tools first:
> - **Ubuntu/Debian:** `sudo apt-get install python3-dev default-libmysqlclient-dev build-essential`
> - **macOS:** `brew install mysql-client pkg-config`
> - **Windows:** Use `pip install mysqlclient` (use pre-built wheel from https://www.lfd.uci.edu/~gohlke/pythonlibs/)

### 5. Run Migrations (creates all MySQL tables)
```bash
python manage.py makemigrations accounts
python manage.py makemigrations esg
python manage.py migrate
```

### 6. Create Admin Superuser
```bash
python manage.py createsuperuser
# Enter email, name, password
# Role will be 'manager' by default for superusers
```

### 7. Run the Development Server
```bash
python manage.py runserver
```

### 8. Open in Browser
| URL                              | Page                        |
|----------------------------------|-----------------------------|
| http://127.0.0.1:8000/           | Landing page                |
| http://127.0.0.1:8000/register/  | Register new account        |
| http://127.0.0.1:8000/login/     | Login                       |
| http://127.0.0.1:8000/dashboard/ | ESG Dashboard (auth required)|
| http://127.0.0.1:8000/data-entry/| ESG Data Entry wizard       |
| http://127.0.0.1:8000/reports/   | Reports (Manager only)      |
| http://127.0.0.1:8000/admin/     | Django Admin panel          |

---

## Role-Based Access

| Feature            | ESG Manager | Company User |
|--------------------|:-----------:|:------------:|
| Dashboard          | ✅ All data | ✅ Own data  |
| Data Entry         | ✅          | ✅           |
| Reports            | ✅          | ❌ Locked    |
| Admin Panel        | ✅          | ❌           |
| Approve Records    | ✅          | ❌           |

---

## ESG Scoring Algorithm

```
Total Score = (Environmental × 0.40) + (Social × 0.30) + (Governance × 0.30)
```

### Environmental Score Factors (0–100):
- Renewable energy % → up to +20 pts
- Waste recycling rate → up to +15 pts
- Environmental policy → +5 pts
- Renewable energy target → +5 pts
- Trees planted → up to +5 pts
- Environmental fines → penalty up to -15 pts

### Social Score Factors (0–100):
- Gender diversity % → up to +15 pts
- Workplace injury rate → up to +15 pts
- Training hours per employee → up to +10 pts
- CSR spend → up to +5 pts
- Health & Diversity policies → +5 pts

### Governance Score Factors (0–100):
- Board independence % → up to +20 pts
- 4 policy types (code of ethics, anti-corruption, data privacy, whistleblower) → +5 pts each
- Risk assessment → +5 pts
- Internal audits → +5 pts
- Compliance violations → -5 pts each (capped at -20)
- Regulatory fines → penalty up to -10 pts
- ESG report published → +5 pts

---

## Data Flow

```
User registers/logs in (MySQL: esg_users)
    ↓
User selects company + period (MySQL: esg_records)
    ↓
Step 1: Environmental form (MySQL: esg_environmental)
    → env_score calculated & saved
    ↓
Step 2: Social form (MySQL: esg_social)
    → social_score calculated & saved
    ↓
Step 3: Governance form (MySQL: esg_governance)
    → gov_score calculated & saved
    → total_score = E×0.4 + S×0.3 + G×0.3
    ↓
Review & Submit → status = 'submitted'
    ↓
Dashboard shows real-time charts from DB
Reports page shows analytics (Manager only)
Chatbot API queries DB for live scores
```

---

## Static Files for Production
```bash
python manage.py collectstatic
```
Then configure nginx/Apache to serve `/staticfiles/`.

---

## Optional: Load Sample Data
```bash
python manage.py shell
```
```python
from accounts.models import User
from esg.models import ESGRecord, EnvironmentalData, SocialData, GovernanceData

u = User.objects.create_user(email='manager@esgpulse.com', password='Test@1234',
    full_name='ESG Manager', company='Demo Corp', role='manager')

r = ESGRecord.objects.create(user=u, company='Demo Corp', period_month=1, period_year=2025, status='published')

env = EnvironmentalData.objects.create(record=r, total_energy_kwh=50000, renewable_energy_kwh=30000,
    scope1_emissions=200, scope2_emissions=150, total_waste_tons=100, waste_recycled_tons=70,
    trees_planted=500, has_env_policy=True, has_renewable_target=True)
r.env_score = env.compute_score()

soc = SocialData.objects.create(record=r, total_employees=200, female_employees=90,
    workplace_injuries=2, total_training_hrs=1600, csr_spend_inr=500000,
    has_health_policy=True, has_diversity_policy=True)
r.social_score = soc.compute_score()

gov = GovernanceData.objects.create(record=r, board_size=10, independent_directors=6,
    has_code_of_ethics=True, has_anti_corruption=True, has_data_privacy=True,
    has_whistleblower=True, risk_assessment_done=True, internal_audits_done=True,
    esg_report_published=True)
r.gov_score = gov.compute_score()
r.calculate_total()
r.save()
print(f'Total ESG Score: {r.total_score}')
```
