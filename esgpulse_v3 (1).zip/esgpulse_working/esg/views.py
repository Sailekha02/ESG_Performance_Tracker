from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Avg
from django.utils import timezone
import json
from django.db import IntegrityError

from .models import ESGRecord, EnvironmentalData, SocialData, GovernanceData, Notification
from .forms import ESGRecordForm, EnvironmentalForm, SocialForm, GovernanceForm

# ─────────────────────────────────────────────
#  NOTIFICATION HELPERS
# ─────────────────────────────────────────────
def generate_notifications(user):
    """Auto-generate smart notifications based on user's ESG data."""
    if user.is_manager:
        records = ESGRecord.objects.all()
    else:
        records = ESGRecord.objects.filter(company=user.company)

    existing_msgs = set(Notification.objects.filter(user=user).values_list('message', flat=True))

    def add_notif(ntype, msg):
        if msg not in existing_msgs:
            Notification.objects.create(user=user, notif_type=ntype, message=msg)

    # Missing data alerts
    draft_count = records.filter(status='draft').count()
    if draft_count > 0:
        add_notif('missing_data', f'You have {draft_count} ESG draft(s) with incomplete data. Please complete and submit.')

    # Low score alerts
    for r in records.filter(env_score__lt=50):
        add_notif('low_score', f'{r.company} Environmental score is low ({r.env_score:.1f}/100) for {r.period_label}. Review energy & emissions data.')
    for r in records.filter(gov_score__lt=50):
        add_notif('low_score', f'{r.company} Governance score needs attention ({r.gov_score:.1f}/100) for {r.period_label}.')
    for r in records.filter(social_score__lt=50):
        add_notif('low_score', f'{r.company} Social score is below benchmark ({r.social_score:.1f}/100) for {r.period_label}.')

    # Submission updates
    for r in records.filter(status='submitted'):
        add_notif('submission', f'{r.company} ESG submission for {r.period_label} is under review by the manager.')

    # Reminder if no data for current quarter
    import datetime
    today = datetime.date.today()
    current_q_records = records.filter(period_year=today.year, period_month__gte=(((today.month-1)//3)*3+1))
    if not current_q_records.exists():
        add_notif('reminder', f'Reminder: No ESG data submitted for Q{((today.month-1)//3)+1} {today.year}. Submit your data to stay compliant.')

    # Performance update for published records
    published = records.filter(status='published')
    if published.exists():
        avg = published.aggregate(avg_total=Avg('total_score'))
        avg_val = avg['avg_total']
        if avg_val:
            if avg_val >= 75:
                add_notif('update', f'Great performance! Your average ESG score is {avg_val:.1f}/100 — above industry benchmark of 70.')
            elif avg_val < 60:
                add_notif('update', f'Your average ESG score is {avg_val:.1f}/100. Focus on environmental and governance improvements.')


# ─────────────────────────────────────────────
#  DASHBOARD
# ─────────────────────────────────────────────
@login_required
def dashboard(request):
    user = request.user

    if user.is_manager:
        records = ESGRecord.objects.all()
    else:
        records = ESGRecord.objects.filter(company=user.company)

    published = records.filter(status='published')

    latest = published.first()
    avg_scores = published.aggregate(
        avg_env=Avg('env_score'),
        avg_soc=Avg('social_score'),
        avg_gov=Avg('gov_score'),
        avg_total=Avg('total_score'),
    )

    trend_records = published[:12]
    trend_labels = [r.period_label for r in reversed(list(trend_records))]
    trend_env = [float(r.env_score) for r in reversed(list(trend_records))]
    trend_soc = [float(r.social_score) for r in reversed(list(trend_records))]
    trend_gov = [float(r.gov_score) for r in reversed(list(trend_records))]
    trend_total = [float(r.total_score) for r in reversed(list(trend_records))]

    recent = records.order_by('-created_at')[:8]

    alerts = []
    for r in records.filter(env_score__lt=50):
        alerts.append({'type': 'red', 'msg': f'{r.company}: Environmental score below 50 ({r.env_score})', 'time': r.updated_at})
    for r in records.filter(gov_score__lt=60):
        alerts.append({'type': 'yellow', 'msg': f'{r.company}: Governance score needs attention ({r.gov_score})', 'time': r.updated_at})
    for r in records.filter(status='submitted'):
        alerts.append({'type': 'blue', 'msg': f'{r.company}: ESG submission under review ({r.period_label})', 'time': r.updated_at})

    # Auto-generate notifications on dashboard load
    generate_notifications(user)

    context = {
        'user': user,
        'latest': latest,
        'avg_scores': avg_scores,
        'total_records': records.count(),
        'published_count': published.count(),
        'trend_labels': json.dumps(trend_labels),
        'trend_env': json.dumps(trend_env),
        'trend_soc': json.dumps(trend_soc),
        'trend_gov': json.dumps(trend_gov),
        'trend_total': json.dumps(trend_total),
        'recent': recent,
        'alerts': alerts[:5],
    }
    return render(request, 'esg/dashboard.html', context)


# ─────────────────────────────────────────────
#  DATA ENTRY — Multi-step wizard
# ─────────────────────────────────────────────
@login_required
def data_entry(request):
    form = ESGRecordForm(initial={'company': request.user.company})
    if request.method == 'POST':
        form = ESGRecordForm(request.POST)
        if form.is_valid():
            try:
                record = form.save(commit=False)
                record.user = request.user
                if not record.company:
                    record.company = request.user.company
                record.save()
                return redirect('data_entry_env', record_id=record.id)
            except IntegrityError:
                messages.error(request, "A record for this company and period already exists.")
        else:
            messages.error(request, 'Please fix the errors below.')
    return render(request, 'esg/data_entry_start.html', {'form': form})


@login_required
def data_entry_env(request, record_id):
    record = get_object_or_404(ESGRecord, id=record_id, user=request.user)
    try:
        instance = record.environmental
    except EnvironmentalData.DoesNotExist:
        instance = None
    form = EnvironmentalForm(instance=instance)
    if request.method == 'POST':
        form = EnvironmentalForm(request.POST, instance=instance)
        if form.is_valid():
            env = form.save(commit=False)
            env.record = record
            env.save()
            record.env_score = env.compute_score()
            record.save()
            return redirect('data_entry_social', record_id=record.id)
    return render(request, 'esg/data_entry_env.html', {'form': form, 'record': record, 'step': 1})


@login_required
def data_entry_social(request, record_id):
    record = get_object_or_404(ESGRecord, id=record_id, user=request.user)
    try:
        instance = record.social
    except SocialData.DoesNotExist:
        instance = None
    form = SocialForm(instance=instance)
    if request.method == 'POST':
        form = SocialForm(request.POST, instance=instance)
        if form.is_valid():
            soc = form.save(commit=False)
            soc.record = record
            soc.save()
            record.social_score = soc.compute_score()
            record.save()
            return redirect('data_entry_gov', record_id=record.id)
    return render(request, 'esg/data_entry_social.html', {'form': form, 'record': record, 'step': 2})


@login_required
def data_entry_gov(request, record_id):
    record = get_object_or_404(ESGRecord, id=record_id, user=request.user)
    try:
        instance = record.governance
    except GovernanceData.DoesNotExist:
        instance = None
    form = GovernanceForm(instance=instance)
    if request.method == 'POST':
        form = GovernanceForm(request.POST, request.FILES, instance=instance)
        if form.is_valid():
            gov = form.save(commit=False)
            gov.record = record
            gov.save()
            record.gov_score = gov.compute_score()
            record.calculate_total()
            record.save()
            return redirect('data_entry_review', record_id=record.id)
    return render(request, 'esg/data_entry_gov.html', {'form': form, 'record': record, 'step': 3})


@login_required
def data_entry_review(request, record_id):
    record = get_object_or_404(ESGRecord, id=record_id, user=request.user)
    if request.method == 'POST':
        record.status = 'submitted'
        record.save()
        # Create submission notification
        Notification.objects.create(
            user=request.user,
            notif_type='submission',
            message=f'Your ESG data for {record.company} ({record.period_label}) has been submitted successfully. Score: {record.total_score}/100.'
        )
        messages.success(request, f'ESG data submitted! Total Score: {record.total_score}')
        return redirect('dashboard')
    return render(request, 'esg/data_entry_review.html', {'record': record, 'step': 4})


# ─────────────────────────────────────────────
#  REPORTS
# ─────────────────────────────────────────────
@login_required
def reports(request):
    if not request.user.is_manager:
        messages.error(request, 'Reports are accessible to ESG Managers only.')
        return redirect('dashboard')

    records = ESGRecord.objects.filter(status='published')
    company_filter = request.GET.get('company', '')
    year_filter = request.GET.get('year', '')
    month_filter = request.GET.get('month', '')

    if company_filter:
        records = records.filter(company__icontains=company_filter)
    if year_filter:
        records = records.filter(period_year=year_filter)
    if month_filter:
        records = records.filter(period_month=month_filter)

    avg = records.aggregate(
        avg_env=Avg('env_score'),
        avg_soc=Avg('social_score'),
        avg_gov=Avg('gov_score'),
        avg_total=Avg('total_score'),
    )

    quarters = {}
    for r in records:
        q = f'Q{((r.period_month - 1) // 3) + 1} {r.period_year}'
        if q not in quarters:
            quarters[q] = {'env': [], 'soc': [], 'gov': []}
        quarters[q]['env'].append(float(r.env_score))
        quarters[q]['soc'].append(float(r.social_score))
        quarters[q]['gov'].append(float(r.gov_score))

    bar_labels = list(quarters.keys())[-6:]
    bar_env = [round(sum(quarters[q]['env']) / len(quarters[q]['env']), 1) for q in bar_labels]
    bar_soc = [round(sum(quarters[q]['soc']) / len(quarters[q]['soc']), 1) for q in bar_labels]
    bar_gov = [round(sum(quarters[q]['gov']) / len(quarters[q]['gov']), 1) for q in bar_labels]

    companies = ESGRecord.objects.values_list('company', flat=True).distinct()

    import datetime
    current_year = datetime.date.today().year
    years = list(range(current_year - 3, current_year + 1))
    form_months = [
        (1,'January'),(2,'February'),(3,'March'),(4,'April'),
        (5,'May'),(6,'June'),(7,'July'),(8,'August'),
        (9,'September'),(10,'October'),(11,'November'),(12,'December'),
    ]

    context = {
        'records': records[:50],
        'avg': avg,
        'companies': companies,
        'years': years,
        'form_months': form_months,
        'bar_labels': json.dumps(bar_labels),
        'bar_env': json.dumps(bar_env),
        'bar_soc': json.dumps(bar_soc),
        'bar_gov': json.dumps(bar_gov),
        'selected_company': company_filter,
        'selected_year': year_filter,
        'selected_month': month_filter,
    }
    return render(request, 'esg/reports.html', context)


# ─────────────────────────────────────────────
#  MANAGEMENT VIEWS (replaces Django /admin/ links)
# ─────────────────────────────────────────────
@login_required
def all_records(request):
    if not request.user.is_manager:
        messages.error(request, 'Access denied. ESG Managers only.')
        return redirect('dashboard')

    from django.contrib.auth import get_user_model
    User = get_user_model()

    records = ESGRecord.objects.select_related('user').order_by('-created_at')

    # Filters
    company_f = request.GET.get('company', '')
    status_f  = request.GET.get('status', '')
    if company_f:
        records = records.filter(company__icontains=company_f)
    if status_f:
        records = records.filter(status=status_f)

    # Approve/Reject/Delete actions
    if request.method == 'POST':
        action    = request.POST.get('action')
        record_id = request.POST.get('record_id')
        if record_id:
            rec = get_object_or_404(ESGRecord, id=record_id)
            if action == 'approve':
                rec.status = 'published'
                rec.save()
                Notification.objects.create(
                    user=rec.user,
                    notif_type='update',
                    message=f'Your ESG submission for {rec.company} ({rec.period_label}) has been approved and published! Score: {rec.total_score}/100.'
                )
                messages.success(request, f'Record #{record_id} approved and published.')
            elif action == 'reject':
                rec.status = 'draft'
                rec.save()
                Notification.objects.create(
                    user=rec.user,
                    notif_type='missing_data',
                    message=f'Your ESG submission for {rec.company} ({rec.period_label}) was returned for revision. Please review and resubmit.'
                )
                messages.warning(request, f'Record #{record_id} returned to draft.')
            elif action == 'delete':
                rec.delete()
                messages.success(request, f'Record #{record_id} deleted.')
        return redirect('all_records')

    companies = ESGRecord.objects.values_list('company', flat=True).distinct()
    context = {
        'records': records,
        'companies': companies,
        'selected_company': company_f,
        'selected_status': status_f,
        'total': records.count(),
    }
    return render(request, 'esg/all_records.html', context)


@login_required
def manage_users(request):
    if not request.user.is_manager:
        messages.error(request, 'Access denied. ESG Managers only.')
        return redirect('dashboard')

    from django.contrib.auth import get_user_model
    User = get_user_model()

    users = User.objects.all().order_by('-date_joined')

    if request.method == 'POST':
        action  = request.POST.get('action')
        user_id = request.POST.get('user_id')
        if user_id:
            target = get_object_or_404(User, id=user_id)
            if action == 'promote' and target != request.user:
                target.role = 'manager'
                target.is_staff = True
                target.save()
                messages.success(request, f'{target.full_name} promoted to ESG Manager.')
            elif action == 'demote' and target != request.user:
                target.role = 'user'
                target.is_staff = False
                target.save()
                messages.success(request, f'{target.full_name} changed to Company User.')
            elif action == 'deactivate' and target != request.user:
                target.is_active = False
                target.save()
                messages.warning(request, f'{target.full_name} deactivated.')
            elif action == 'activate':
                target.is_active = True
                target.save()
                messages.success(request, f'{target.full_name} activated.')
        return redirect('manage_users')

    context = {
        'users': users,
        'total_users': users.count(),
        'managers': users.filter(role='manager').count(),
        'active_users': users.filter(is_active=True).count(),
    }
    return render(request, 'esg/manage_users.html', context)


@login_required
def admin_panel(request):
    if not request.user.is_manager:
        messages.error(request, 'Access denied. ESG Managers only.')
        return redirect('dashboard')

    from django.contrib.auth import get_user_model
    User = get_user_model()

    # System stats
    total_users    = User.objects.count()
    total_records  = ESGRecord.objects.count()
    published      = ESGRecord.objects.filter(status='published').count()
    submitted      = ESGRecord.objects.filter(status='submitted').count()
    drafts         = ESGRecord.objects.filter(status='draft').count()
    avg_scores     = ESGRecord.objects.filter(status='published').aggregate(
        avg_env=Avg('env_score'), avg_soc=Avg('social_score'),
        avg_gov=Avg('gov_score'), avg_total=Avg('total_score'),
    )
    recent_users   = User.objects.order_by('-date_joined')[:5]
    recent_records = ESGRecord.objects.order_by('-created_at')[:5]
    unread_notifs  = Notification.objects.filter(is_read=False).count()

    context = {
        'total_users': total_users,
        'total_records': total_records,
        'published': published,
        'submitted': submitted,
        'drafts': drafts,
        'avg_scores': avg_scores,
        'recent_users': recent_users,
        'recent_records': recent_records,
        'unread_notifs': unread_notifs,
    }
    return render(request, 'esg/admin_panel.html', context)


# ─────────────────────────────────────────────
#  NOTIFICATIONS API
# ─────────────────────────────────────────────
@login_required
def notifications_api(request):
    generate_notifications(request.user)
    # Only return unread notifications — read ones are deleted on marking
    notifs = Notification.objects.filter(user=request.user, is_read=False)[:15]
    data = [{
        'id':      n.id,
        'message': n.message,
        'color':   n.color,
        'read':    n.is_read,
        'time':    n.created_at.strftime('%b %d, %Y %H:%M'),
    } for n in notifs]
    return JsonResponse({'notifications': data, 'unread': len(data)})


@login_required
def notification_mark_read(request, notif_id):
    # Mark as read AND delete so it disappears from the list
    if request.method == 'POST':
        Notification.objects.filter(id=notif_id, user=request.user).delete()
    return JsonResponse({'ok': True})


@login_required
def notification_mark_all_read(request):
    # Delete all notifications for this user
    if request.method == 'POST':
        Notification.objects.filter(user=request.user).delete()
    return JsonResponse({'ok': True})


# ─────────────────────────────────────────────
#  THEME PREFERENCE (Cookie via AJAX)
# ─────────────────────────────────────────────
@login_required
def set_theme(request):
    if request.method == 'POST':
        data  = json.loads(request.body)
        theme = data.get('theme', 'light')
        request.session['theme'] = theme
    return JsonResponse({'ok': True})


# ─────────────────────────────────────────────
#  CHATBOT API  (enhanced)
# ─────────────────────────────────────────────
@login_required
def chatbot_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST only'}, status=405)

    data = json.loads(request.body)
    msg  = data.get('message', '').lower().strip()
    user = request.user

    if user.is_manager:
        records = ESGRecord.objects.filter(status='published')
    else:
        records = ESGRecord.objects.filter(company=user.company, status='published')

    avg = records.aggregate(
        avg_env=Avg('env_score'), avg_soc=Avg('social_score'),
        avg_gov=Avg('gov_score'), avg_total=Avg('total_score'),
    )
    def fmt(v): return f'{float(v):.1f}' if v else 'N/A'

    # ── Greeting ──
    if any(w in msg for w in ['hello', 'hi', 'hey', 'help', 'what can you do']):
        reply = (f"👋 Hi {user.full_name}! I'm your ESG Assistant. I can help you with:<br>"
                 "• 📊 <b>ESG scores</b> — ask about your current scores<br>"
                 "• 📝 <b>Form guidance</b> — step-by-step data entry help<br>"
                 "• 🌍 <b>Metric explanations</b> — what each metric means<br>"
                 "• 📈 <b>Improvement tips</b> — how to boost your scores<br>"
                 "• 🧭 <b>Navigation</b> — how to use the system<br><br>"
                 "Try: <i>'What is my ESG score?'</i> or <i>'How do I fill the environmental form?'</i>")

    # ── Scores ──
    elif any(w in msg for w in ['score', 'rating', 'esg score', 'total score', 'my score', 'performance']):
        reply = (f"📊 <b>Your ESG Scores</b><br>"
                 f"🌱 Total ESG: <b>{fmt(avg['avg_total'])}/100</b><br>"
                 f"🌍 Environmental: <b>{fmt(avg['avg_env'])}/100</b> (Weight: 40%)<br>"
                 f"👥 Social: <b>{fmt(avg['avg_soc'])}/100</b> (Weight: 30%)<br>"
                 f"🏛️ Governance: <b>{fmt(avg['avg_gov'])}/100</b> (Weight: 30%)<br><br>"
                 "Scores above 70 are considered industry-benchmark performance.")

    # ── Environmental ──
    elif any(w in msg for w in ['environment', 'environmental', 'carbon', 'emission', 'energy', 'water', 'waste', 'green']):
        reply = (f"🌍 <b>Environmental Score: {fmt(avg['avg_env'])}/100</b><br><br>"
                 "<b>What's tracked:</b><br>"
                 "• ⚡ Energy use (kWh) & renewable % — higher renewable = better<br>"
                 "• 💨 Scope 1/2/3 carbon emissions (tCO₂e)<br>"
                 "• 💧 Water consumption & recycled water %<br>"
                 "• 🗑️ Total waste & recycling rate<br><br>"
                 "<b>Quick wins:</b> Add renewable energy targets, adopt an environmental policy, increase recycling rates.")

    # ── Social ──
    elif any(w in msg for w in ['social', 'employee', 'diversity', 'safety', 'training', 'csr', 'workforce']):
        reply = (f"👥 <b>Social Score: {fmt(avg['avg_soc'])}/100</b><br><br>"
                 "<b>What's tracked:</b><br>"
                 "• 👩‍💼 Gender diversity (% female employees & leadership)<br>"
                 "• 🦺 Workplace safety — injuries, lost-time incidents<br>"
                 "• 📚 Training hours per employee<br>"
                 "• 🤝 CSR spend & community programs<br><br>"
                 "<b>Quick wins:</b> Increase female leadership %, add safety training hours, expand CSR programmes.")

    # ── Governance ──
    elif any(w in msg for w in ['governance', 'board', 'policy', 'compliance', 'audit', 'ethics', 'risk']):
        reply = (f"🏛️ <b>Governance Score: {fmt(avg['avg_gov'])}/100</b><br><br>"
                 "<b>What's tracked:</b><br>"
                 "• 🏦 Board independence % (independent directors)<br>"
                 "• 📋 Policies: Code of Ethics, Anti-Corruption, Data Privacy, Whistleblower<br>"
                 "• 🔍 Risk assessment, internal audits, ESG report publication<br>"
                 "• ⚠️ Compliance violations & regulatory fines (negative impact)<br><br>"
                 "<b>Quick wins:</b> Adopt all four policies (+20 pts), publish ESG report (+5 pts).")

    # ── Form / Data entry guidance ──
    elif any(w in msg for w in ['form', 'fill', 'entry', 'data entry', 'how to', 'submit', 'input', 'enter data']):
        reply = ("📝 <b>How to fill the ESG Form</b><br><br>"
                 "<b>Step 1 — Start:</b> Click '+ New Entry' → Enter company name, month & year<br>"
                 "<b>Step 2 — Environmental:</b> Fill energy, emissions, water & waste data<br>"
                 "<b>Step 3 — Social:</b> Enter employee count, diversity, safety & training data<br>"
                 "<b>Step 4 — Governance:</b> Board info, policies (checkboxes), audit details<br>"
                 "<b>Step 5 — Review:</b> Check all scores and click 'Submit for Review'<br><br>"
                 "💡 <i>Tip: Each field has a tooltip. Leave optional fields as 0 if not applicable.</i>")

    # ── Improve / suggestions ──
    elif any(w in msg for w in ['improve', 'increase', 'boost', 'better', 'suggestion', 'tips', 'how to improve']):
        env_v = float(avg['avg_env'] or 0)
        soc_v = float(avg['avg_soc'] or 0)
        gov_v = float(avg['avg_gov'] or 0)
        lowest = min([(env_v, 'Environmental'), (soc_v, 'Social'), (gov_v, 'Governance')], key=lambda x: x[0])
        tips = {
            'Environmental': "• Switch to renewable energy sources<br>• Improve waste recycling rates<br>• Adopt an environmental policy<br>• Set renewable energy targets",
            'Social': "• Increase female leadership representation<br>• Reduce workplace injuries with safety training<br>• Expand CSR programs & community outreach<br>• Add employee training hours",
            'Governance': "• Adopt Code of Ethics & Anti-Corruption policy<br>• Enable Whistleblower protection<br>• Conduct annual internal audits<br>• Publish your ESG report publicly",
        }
        reply = (f"📈 <b>Improvement Suggestions</b><br><br>"
                 f"Your lowest score is <b>{lowest[1]}: {lowest[0]:.1f}/100</b>. Focus here first:<br><br>"
                 f"{tips[lowest[1]]}<br><br>"
                 "Ask me about any specific pillar for more detailed guidance!")

    # ── Navigation ──
    elif any(w in msg for w in ['navigate', 'navigation', 'where', 'find', 'go to', 'page', 'menu', 'dashboard', 'report', 'records', 'users']):
        reply = ("🧭 <b>System Navigation Guide</b><br><br>"
                 "📊 <b>Dashboard</b> — Overview of ESG scores, trends & alerts<br>"
                 "📝 <b>Data Entry</b> — Submit new ESG data (4-step wizard)<br>"
                 "📄 <b>Reports</b> — Analytics & filtered views (Managers only)<br>"
                 "🏢 <b>All Records</b> — Review & approve submissions (Managers only)<br>"
                 "👥 <b>Users</b> — Manage user accounts & roles (Managers only)<br>"
                 "⚙️ <b>Admin Panel</b> — System overview & stats (Managers only)<br><br>"
                 "Use the sidebar on the left to navigate between pages.")

    # ── Reports ──
    elif any(w in msg for w in ['report', 'download', 'export', 'pdf', 'excel']):
        if user.is_manager:
            reply = ("📄 <b>Reports & Analytics</b><br><br>"
                     "Go to <b>Reports</b> in the sidebar to:<br>"
                     "• Filter by company, year, or month<br>"
                     "• View quarterly bar charts & trend data<br>"
                     "• See average E, S, G scores per period<br>"
                     "• Export to PDF or Excel format<br><br>"
                     "The report section shows only <i>published</i> records.")
        else:
            reply = "📄 Reports are accessible to ESG Managers only. Contact your manager to generate reports for your company."

    # ── Default ──
    else:
        reply = (f"🤖 I can help with ESG topics! Try asking:<br>"
                 "• <i>'What is my ESG score?'</i><br>"
                 "• <i>'How to fill the environmental form?'</i><br>"
                 "• <i>'How can I improve my governance score?'</i><br>"
                 "• <i>'Explain social metrics'</i><br>"
                 "• <i>'How do I navigate the system?'</i>")

    return JsonResponse({'reply': reply})
