from django import forms
from .models import ESGRecord, EnvironmentalData, SocialData, GovernanceData
import datetime


CURRENT_YEAR = datetime.date.today().year
YEAR_CHOICES = [(y, y) for y in range(CURRENT_YEAR - 3, CURRENT_YEAR + 1)]
MONTH_CHOICES = [
    (1,'January'),(2,'February'),(3,'March'),(4,'April'),
    (5,'May'),(6,'June'),(7,'July'),(8,'August'),
    (9,'September'),(10,'October'),(11,'November'),(12,'December'),
]


class ESGRecordForm(forms.ModelForm):
    period_month = forms.TypedChoiceField(choices=MONTH_CHOICES, coerce=int)
    period_year = forms.TypedChoiceField(choices=YEAR_CHOICES, coerce=int)

    class Meta:
        model = ESGRecord
        fields = ['company', 'period_month', 'period_year']


class EnvironmentalForm(forms.ModelForm):
    class Meta:
        model = EnvironmentalData
        exclude = ['record']
        widgets = {
            'total_energy_kwh': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'renewable_energy_kwh': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'scope1_emissions': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'scope2_emissions': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'scope3_emissions': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'water_consumption_kl': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'water_recycled_kl': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'total_waste_tons': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'waste_recycled_tons': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'hazardous_waste_tons': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'trees_planted': forms.NumberInput(attrs={'placeholder': '0'}),
            'environmental_fines': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
        }


class SocialForm(forms.ModelForm):
    class Meta:
        model = SocialData
        exclude = ['record']
        widgets = {
            'total_employees': forms.NumberInput(attrs={'placeholder': '0'}),
            'female_employees': forms.NumberInput(attrs={'placeholder': '0'}),
            'new_hires': forms.NumberInput(attrs={'placeholder': '0'}),
            'employee_turnover_pct': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'workplace_injuries': forms.NumberInput(attrs={'placeholder': '0'}),
            'lost_time_injuries': forms.NumberInput(attrs={'placeholder': '0'}),
            'safety_training_hrs': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'total_training_hrs': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'training_spend_inr': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'csr_spend_inr': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
            'community_programs': forms.NumberInput(attrs={'placeholder': '0'}),
            'beneficiaries_count': forms.NumberInput(attrs={'placeholder': '0'}),
            'female_leadership_pct': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
        }


class GovernanceForm(forms.ModelForm):
    class Meta:
        model = GovernanceData
        exclude = ['record', 'audit_report']
        widgets = {
            'board_size': forms.NumberInput(attrs={'placeholder': '0'}),
            'independent_directors': forms.NumberInput(attrs={'placeholder': '0'}),
            'female_board_members': forms.NumberInput(attrs={'placeholder': '0'}),
            'board_meetings_per_year': forms.NumberInput(attrs={'placeholder': '0'}),
            'compliance_violations': forms.NumberInput(attrs={'placeholder': '0'}),
            'regulatory_fines_inr': forms.NumberInput(attrs={'placeholder': '0.00', 'step': '0.01'}),
        }
