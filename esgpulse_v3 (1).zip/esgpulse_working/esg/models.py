from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator


class ESGRecord(models.Model):
    """
    Master ESG record linking all three pillars.
    Stores calculated scores and submission metadata.
    """
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('submitted', 'Under Review'),
        ('published', 'Published'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='esg_records'
    )
    company = models.CharField(max_length=200)
    period_month = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(12)]
    )
    period_year = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')

    # Calculated scores (0–100)
    env_score = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    social_score = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    gov_score = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    total_score = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'esg_records'
        ordering = ['-period_year', '-period_month', '-created_at']
        unique_together = ['user', 'company', 'period_month', 'period_year']

    def __str__(self):
        return f'{self.company} — {self.period_month}/{self.period_year} ({self.total_score})'

    def calculate_total(self):
        """Weighted: E=40%, S=30%, G=30%"""
        total = (
            float(self.env_score) * 0.40 +
            float(self.social_score) * 0.30 +
            float(self.gov_score) * 0.30
        )
        self.total_score = round(total, 2)
        return self.total_score

    @property
    def period_label(self):
        import calendar
        return f"{calendar.month_abbr[self.period_month]} {self.period_year}"


class EnvironmentalData(models.Model):
    """Environmental pillar data — Energy, Emissions, Water, Waste"""
    record = models.OneToOneField(
        ESGRecord, on_delete=models.CASCADE, related_name='environmental'
    )

    # Energy
    total_energy_kwh = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    renewable_energy_kwh = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Emissions (tCO2e)
    scope1_emissions = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    scope2_emissions = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    scope3_emissions = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    # Water
    water_consumption_kl = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    water_recycled_kl = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    # Waste
    total_waste_tons = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    waste_recycled_tons = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    hazardous_waste_tons = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    # Initiatives
    trees_planted = models.PositiveIntegerField(default=0)
    has_env_policy = models.BooleanField(default=False)
    has_renewable_target = models.BooleanField(default=False)
    environmental_fines = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    class Meta:
        db_table = 'esg_environmental'

    def __str__(self):
        return f'Env — {self.record}'

    @property
    def renewable_pct(self):
        if self.total_energy_kwh:
            return round((float(self.renewable_energy_kwh) / float(self.total_energy_kwh)) * 100, 1)
        return 0

    @property
    def recycling_rate(self):
        if self.total_waste_tons:
            return round((float(self.waste_recycled_tons) / float(self.total_waste_tons)) * 100, 1)
        return 0

    def compute_score(self):
        """Score 0–100 based on key environmental metrics"""
        score = 50  # baseline

        # Renewable energy % (up to +20)
        score += min(self.renewable_pct * 0.2, 20)

        # Waste recycling rate (up to +15)
        score += min(self.recycling_rate * 0.15, 15)

        # Policy presence (up to +10)
        if self.has_env_policy:
            score += 5
        if self.has_renewable_target:
            score += 5

        # Trees planted (up to +5)
        if self.trees_planted > 0:
            score += min(self.trees_planted / 100, 5)

        # Penalties (up to -15)
        if float(self.environmental_fines) > 0:
            score -= min(float(self.environmental_fines) / 10000, 15)

        return round(min(max(score, 0), 100), 2)


class SocialData(models.Model):
    """Social pillar — Workforce, Safety, Community, Diversity"""
    record = models.OneToOneField(
        ESGRecord, on_delete=models.CASCADE, related_name='social'
    )

    # Workforce
    total_employees = models.PositiveIntegerField(default=0)
    female_employees = models.PositiveIntegerField(default=0)
    new_hires = models.PositiveIntegerField(default=0)
    employee_turnover_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    # Health & Safety
    workplace_injuries = models.PositiveIntegerField(default=0)
    lost_time_injuries = models.PositiveIntegerField(default=0)
    safety_training_hrs = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    has_health_policy = models.BooleanField(default=False)

    # Training & Development
    total_training_hrs = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    training_spend_inr = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Community & CSR
    csr_spend_inr = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    community_programs = models.PositiveIntegerField(default=0)
    beneficiaries_count = models.PositiveIntegerField(default=0)

    # Leadership Diversity
    female_leadership_pct = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    has_diversity_policy = models.BooleanField(default=False)

    class Meta:
        db_table = 'esg_social'

    def __str__(self):
        return f'Social — {self.record}'

    @property
    def gender_diversity_pct(self):
        if self.total_employees:
            return round((self.female_employees / self.total_employees) * 100, 1)
        return 0

    def compute_score(self):
        score = 50

        # Gender diversity (up to +15)
        score += min(self.gender_diversity_pct * 0.4, 15)

        # Safety: lower injuries = higher score (up to +15)
        inj_rate = (self.workplace_injuries / max(self.total_employees, 1)) * 100
        score += max(15 - inj_rate * 2, 0)

        # Training hours per employee (up to +10)
        hrs_per_emp = float(self.total_training_hrs) / max(self.total_employees, 1)
        score += min(hrs_per_emp * 0.5, 10)

        # CSR spend (up to +5)
        if float(self.csr_spend_inr) > 0:
            score += min(float(self.csr_spend_inr) / 1000000, 5)

        # Policies
        if self.has_health_policy:
            score += 3
        if self.has_diversity_policy:
            score += 2

        return round(min(max(score, 0), 100), 2)


class GovernanceData(models.Model):
    """Governance pillar — Board, Policies, Risk, Audit"""
    record = models.OneToOneField(
        ESGRecord, on_delete=models.CASCADE, related_name='governance'
    )

    # Board
    board_size = models.PositiveSmallIntegerField(default=0)
    independent_directors = models.PositiveSmallIntegerField(default=0)
    female_board_members = models.PositiveSmallIntegerField(default=0)
    board_meetings_per_year = models.PositiveSmallIntegerField(default=0)

    # Policies
    has_code_of_ethics = models.BooleanField(default=False)
    has_anti_corruption = models.BooleanField(default=False)
    has_data_privacy = models.BooleanField(default=False)
    has_whistleblower = models.BooleanField(default=False)

    # Risk
    risk_assessment_done = models.BooleanField(default=False)
    compliance_violations = models.PositiveIntegerField(default=0)
    regulatory_fines_inr = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    # Audit
    internal_audits_done = models.BooleanField(default=False)
    audit_report = models.FileField(upload_to='audits/', blank=True, null=True)
    esg_report_published = models.BooleanField(default=False)

    class Meta:
        db_table = 'esg_governance'

    def __str__(self):
        return f'Gov — {self.record}'

    @property
    def board_independence_pct(self):
        if self.board_size:
            return round((self.independent_directors / self.board_size) * 100, 1)
        return 0

    def compute_score(self):
        score = 40

        # Board independence (up to +20)
        score += min(self.board_independence_pct * 0.2, 20)

        # Policies (up to +20)
        for field in [self.has_code_of_ethics, self.has_anti_corruption,
                      self.has_data_privacy, self.has_whistleblower]:
            if field:
                score += 5

        # Risk & Audit (up to +10)
        if self.risk_assessment_done:
            score += 5
        if self.internal_audits_done:
            score += 5

        # Penalties (-5 per violation, capped)
        score -= min(self.compliance_violations * 5, 20)
        if float(self.regulatory_fines_inr) > 0:
            score -= min(float(self.regulatory_fines_inr) / 100000, 10)

        # Reporting bonus
        if self.esg_report_published:
            score += 5

        return round(min(max(score, 0), 100), 2)


class Notification(models.Model):
    """
    In-app notifications for ESG users.
    Types: missing_data, low_score, submission, reminder, update
    """
    TYPE_CHOICES = [
        ('missing_data', 'Missing ESG Data'),
        ('low_score',    'Low Score Alert'),
        ('submission',   'Submission Update'),
        ('reminder',     'Reminder'),
        ('update',       'Performance Update'),
    ]
    COLOR_MAP = {
        'missing_data': '#ef4444',
        'low_score':    '#f59e0b',
        'submission':   '#3b82f6',
        'reminder':     '#8b5cf6',
        'update':       '#16a34a',
    }

    user        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    notif_type  = models.CharField(max_length=20, choices=TYPE_CHOICES, default='update')
    message     = models.TextField()
    is_read     = models.BooleanField(default=False)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'esg_notifications'
        ordering = ['-created_at']

    def __str__(self):
        return f'[{self.notif_type}] {self.user} — {self.message[:60]}'

    @property
    def color(self):
        return self.COLOR_MAP.get(self.notif_type, '#6b7280')
