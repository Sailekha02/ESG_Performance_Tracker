from django.contrib import admin
from .models import ESGRecord, EnvironmentalData, SocialData, GovernanceData, Notification


@admin.register(ESGRecord)
class ESGRecordAdmin(admin.ModelAdmin):
    list_display = ['company', 'user', 'period_label', 'total_score', 'status', 'created_at']
    list_filter  = ['status', 'period_year']
    search_fields = ['company', 'user__email']


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['user', 'notif_type', 'message', 'is_read', 'created_at']
    list_filter  = ['notif_type', 'is_read']
    search_fields = ['user__email', 'message']


admin.site.register(EnvironmentalData)
admin.site.register(SocialData)
admin.site.register(GovernanceData)
