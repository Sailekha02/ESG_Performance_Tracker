from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('data-entry/', views.data_entry, name='data_entry'),
    path('data-entry/<int:record_id>/env/', views.data_entry_env, name='data_entry_env'),
    path('data-entry/<int:record_id>/social/', views.data_entry_social, name='data_entry_social'),
    path('data-entry/<int:record_id>/gov/', views.data_entry_gov, name='data_entry_gov'),
    path('data-entry/<int:record_id>/review/', views.data_entry_review, name='data_entry_review'),
    path('reports/', views.reports, name='reports'),

    # Management views (replaces Django /admin/ links)
    path('management/all-records/', views.all_records, name='all_records'),
    path('management/users/', views.manage_users, name='manage_users'),
    path('management/admin-panel/', views.admin_panel, name='admin_panel'),

    # API endpoints
    path('api/chatbot/', views.chatbot_api, name='chatbot_api'),
    path('api/notifications/', views.notifications_api, name='notifications_api'),
    path('api/notifications/read/<int:notif_id>/', views.notification_mark_read, name='notification_mark_read'),
    path('api/notifications/read-all/', views.notification_mark_all_read, name='notification_mark_all_read'),
    path('api/set-theme/', views.set_theme, name='set_theme'),
]
